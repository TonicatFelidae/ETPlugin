ET resource loader
